#import <Flutter/Flutter.h>

@interface BarometerPlugin : NSObject<FlutterPlugin>
@end
