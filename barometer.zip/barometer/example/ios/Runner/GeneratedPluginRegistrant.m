//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<barometer/BarometerPlugin.h>)
#import <barometer/BarometerPlugin.h>
#else
@import barometer;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BarometerPlugin registerWithRegistrar:[registry registrarForPlugin:@"BarometerPlugin"]];
}

@end
